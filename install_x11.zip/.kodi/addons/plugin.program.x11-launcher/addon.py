"""
    Plugin for Launching programs
"""

# -*- coding: UTF-8 -*-
# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon

# plugin constants
__plugin__ = "X11-launcher"
__author__ = "jcnventura"
__url__ = "http://blog.petrockblock.com/retropie/"
__git_url__ = "https://github.com/mcobit/retrosmc/"
__credits__ = "mcobit"
__version__ = "0.0.2"

dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon(id='plugin.program.x11-launcher')

output=os.popen("/home/osmc/x11-start/xstart.sh").read()
#dialog.ok("Starting X11",output)
#print output
